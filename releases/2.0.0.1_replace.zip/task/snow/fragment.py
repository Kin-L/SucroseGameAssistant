from tools.environment import *
from ..default_task import Task


class Fragment(Task):
    def __init__(self):
        super().__init__()

    def snow_fragment(self):
        self.indicate("开始检查：作战。")
        text = ocr((1675, 397, 1802, 439))[0]
        if (":" in text) or ("：" in text):
            self.indicate("重游进行中，不能再次开启作战。")
            click(288, 78)
            wait(1500)
            self.indicate("检查完成：作战。")
            return False

