# -*- coding:gbk -*-
import os
import webbrowser
from .list import SnowList
from .stack import SnowStack
from ui.element.control import *
from tools.environment import env


# ԭ��ģ�����ô���
class Snow:
    def __init__(self, stack, icon, main):
        self.main = main
        self.widget_snow = Widget()
        stack.addWidget(self.widget_snow)
        self.button_snow = (
            PicButton(icon, (55, 0, 50, 50),
                      r"assets\snows\picture\snow-icon.png", (50, 50)))
        self.list = None
        self.set = None

    def load_window(self):
        self.list = SnowList(self.widget_snow, (0, 0, 215, 515))
        self.set = SnowStack(self.widget_snow, (225, 0, 410, 515))
        self.list.set_snow.clicked.connect(lambda: self.set.stack.setCurrentIndex(0))
        self.list.set_share.clicked.connect(lambda: self.set.stack.setCurrentIndex(1))
        self.list.set_fight.clicked.connect(lambda: self.set.stack.setCurrentIndex(2))
        self.list.set_debris.clicked.connect(lambda: self.set.stack.setCurrentIndex(3))
        self.list.set_market.clicked.connect(lambda: self.set.stack.setCurrentIndex(4))
        self.list.set_reward.clicked.connect(lambda: self.set.stack.setCurrentIndex(5))
        self.list.set_proof.clicked.connect(lambda: self.set.stack.setCurrentIndex(6))
        self.list.set_mail.clicked.connect(lambda: self.set.stack.setCurrentIndex(7))
        self.list.set_fragment.clicked.connect(lambda: self.set.stack.setCurrentIndex(8))
        self.list.set_roll.clicked.connect(lambda: self.set.stack.setCurrentIndex(9))
        self.set.button_gift.clicked.connect(self.gift_inquiry)
        self.set.button_wiki.clicked.connect(self.open_wiki)
        self.set.button_arrange.clicked.connect(self.roll_arrange)
        self.set.button_open_roll.clicked.connect(self.open_roll_directory)
        Line(self.widget_snow, (215, 5, 3, 505), False)

    def load_run(self, run):
        server, path = run
        self.set.combo_server.setCurrentIndex(server)
        self.set.line_start.setText(path)
        self.set.line_start.setSelection(0, 0)

    def get_run(self):
        sever = self.set.combo_server.currentIndex()
        start = self.set.line_start.text()
        return [sever, start]

    def input_config(self, config):
        run_list = config["����"]
        self.set.independent.check_mute.setChecked(run_list[0])
        self.set.independent.check_kill_game.setChecked(run_list[1])
        self.set.independent.combo_after.setCurrentIndex(run_list[2])
        self.set.independent.check_kill_sga.setChecked(run_list[3])

        check_list = config["����"]
        self.set.check_share.setChecked(check_list[0])
        self.set.check_fight.setChecked(check_list[1])
        self.set.check_debris.setChecked(check_list[2])
        self.set.check_market.setChecked(check_list[3])
        self.set.check_reward.setChecked(check_list[4])
        self.set.check_proof.setChecked(check_list[5])
        self.set.check_mail.setChecked(check_list[6])
        self.set.check_fragment.setChecked(check_list[7])
        self.set.check_roll.setChecked(check_list[8])

        self.set.mat.setCurrentIndex(config["�ж�"])

        self.set.character1.setCurrentIndex(config["����"][0])
        self.set.character2.setCurrentIndex(config["����"][1])

    def output_config(self):
        config = dict()
        config["ģ��"] = 1
        config["����"] = [self.set.independent.check_mute.isChecked(),
                        self.set.independent.check_kill_game.isChecked(),
                        self.set.independent.combo_after.currentIndex(),
                        self.set.independent.check_kill_sga.isChecked()]
        config["����"] = \
            [self.list.check_share.isChecked(), self.list.check_fight.isChecked(),
             self.list.check_debris.isChecked(), self.list.check_market.isChecked(),
             self.list.check_reward.isChecked(), self.list.check_proof.isChecked(),
             self.list.check_mail.isChecked(), self.list.check_fragment.isChecked(),
             self.list.check_roll.isChecked()]
        config["�ж�"] = self.set.mat.isChecked()
        config["����"] = [self.set.character1.currentIndex(),
                        self.set.character2.currentIndex()]
        return config

    def open_roll_directory(self):
        os.startfile(env.workdir + "/personal/snows/roll")
        self.main.indicate("���ļ���: �����¼", 1)

    def open_recruit_directory(self):
        os.startfile(env.workdir + "/personal/snows/recruit")
        self.main.indicate("���ļ�: ��ļ��ʷ", 1)

    def open_recruit_history(self):
        os.startfile(env.workdir + "/personal/snows/recruit/history.txt")
        self.main.indicate("���ļ���: ��ļ��ͼ", 1)

    def gift_inquiry(self):
        webbrowser.open("https://www.bilibili.com/read/cv24639360/?from=search&spm_id_from=333.337.0.0")
        self.main.indicate("����ҳ: �����Ͽɶȶ��ձ�", 1)

    def open_wiki(self):
        webbrowser.open("https://wiki.biligame.com/kelaiyinshe/%E8%88%8D%E5%8F%8B%E5%9B%BE%E9%89%B4")
        self.main.indicate("����ҳ: �������� BWIKI", 1)

    def roll_arrange(self):
        import json
        with open("personal/snow/roll/history.json", 'r', encoding='utf-8') as m:
            _dir = json.load(m)
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment
        _excel = Workbook()
        sheet0 = _excel.create_sheet("����")
        sheet0["A1"] = "�鿨����"
        sheet0["A2"] = "��������"
        sheet0["B2"] = "N"
        sheet0["C2"] = "R"
        sheet0["D2"] = "SR"
        sheet0["E2"] = "SRR"
        sheet0["F2"] = "�ܳ���"
        sheet0["G2"] = "����ˮλ"
        sheet0["A3"] = "����"

        sheet0["A5"] = "��̬����"
        sheet0["B5"] = "N"
        sheet0["C5"] = "R"
        sheet0["D5"] = "SR"
        sheet0["E5"] = "SSR"
        sheet0["F5"] = "�ܳ���"
        sheet0["G5"] = "����ˮλ"
        sheet0["A6"] = "����"

        sheet0["A8"] = "��ʼ����"
        sheet0["B8"] = "N"
        sheet0["C8"] = "R"
        sheet0["D8"] = "SR"
        sheet0["E8"] = "SRR"
        sheet0["F8"] = "�ܳ���"
        sheet0["G8"] = "����ˮλ"
        sheet0["A9"] = "����"

        fon1 = Font(name='����', size=14, bold=True)
        fon2 = Font(name='����', size=12)
        fon_n = Font(name='����', size=12, color="6C6C6C")
        fon_r = Font(name='����', size=12, color="3374F8")
        fon_sr = Font(name='����', size=12, color="7E30FF", bold=True)
        fon_srr = Font(name='����', size=12, color="FFC332", bold=True)
        al = Alignment(horizontal='center', vertical='center')
        sheet0["A1"].font = fon1

        sheet0["A2"].font = fon1
        sheet0["B2"].font = fon1
        sheet0["C2"].font = fon1
        sheet0["D2"].font = fon1
        sheet0["E2"].font = fon1
        sheet0["F2"].font = fon1
        sheet0["G2"].font = fon1
        sheet0["A3"].font = fon1
        sheet0["B3"].font = fon_n
        sheet0["C3"].font = fon_r
        sheet0["D3"].font = fon_sr
        sheet0["E3"].font = fon_srr
        sheet0["F3"].font = fon2
        sheet0["G3"].font = fon2

        sheet0["A5"].font = fon1
        sheet0["B5"].font = fon1
        sheet0["C5"].font = fon1
        sheet0["D5"].font = fon1
        sheet0["E5"].font = fon1
        sheet0["F5"].font = fon1
        sheet0["G5"].font = fon1
        sheet0["A6"].font = fon1
        sheet0["B6"].font = fon_n
        sheet0["C6"].font = fon_r
        sheet0["D6"].font = fon_sr
        sheet0["E6"].font = fon_srr
        sheet0["F6"].font = fon2
        sheet0["G6"].font = fon2

        sheet0["A8"].font = fon1
        sheet0["B8"].font = fon1
        sheet0["C8"].font = fon1
        sheet0["D8"].font = fon1
        sheet0["E8"].font = fon1
        sheet0["F8"].font = fon1
        sheet0["G8"].font = fon1
        sheet0["A9"].font = fon1
        sheet0["B9"].font = fon_n
        sheet0["C9"].font = fon_r
        sheet0["D9"].font = fon_sr
        sheet0["E9"].font = fon_srr
        sheet0["F9"].font = fon2
        sheet0["G9"].font = fon2
        sheet0.column_dimensions['A'].width = 15
        sheet0.column_dimensions['B'].width = 10
        sheet0.column_dimensions['C'].width = 10
        sheet0.column_dimensions['D'].width = 10
        sheet0.column_dimensions['E'].width = 10
        sheet0.column_dimensions['F'].width = 15
        sheet0.column_dimensions['G'].width = 15
        sheet0["A1"].alignment = al
        sheet0["A1"].alignment = al
        sheet0["A2"].alignment = al
        sheet0["B2"].alignment = al
        sheet0["C2"].alignment = al
        sheet0["D2"].alignment = al
        sheet0["E2"].alignment = al
        sheet0["F2"].alignment = al
        sheet0["G2"].alignment = al
        sheet0["A3"].alignment = al
        sheet0["B3"].alignment = al
        sheet0["C3"].alignment = al
        sheet0["D3"].alignment = al
        sheet0["E3"].alignment = al
        sheet0["F3"].alignment = al
        sheet0["G3"].alignment = al
        sheet0["A5"].alignment = al
        sheet0["B5"].alignment = al
        sheet0["C5"].alignment = al
        sheet0["D5"].alignment = al
        sheet0["E5"].alignment = al
        sheet0["F5"].alignment = al
        sheet0["G5"].alignment = al
        sheet0["A6"].alignment = al
        sheet0["B6"].alignment = al
        sheet0["C6"].alignment = al
        sheet0["D6"].alignment = al
        sheet0["E6"].alignment = al
        sheet0["F6"].alignment = al
        sheet0["G6"].alignment = al
        sheet0["A8"].alignment = al
        sheet0["B8"].alignment = al
        sheet0["C8"].alignment = al
        sheet0["D8"].alignment = al
        sheet0["E8"].alignment = al
        sheet0["F8"].alignment = al
        sheet0["G8"].alignment = al
        sheet0["A9"].alignment = al
        sheet0["B9"].alignment = al
        sheet0["C9"].alignment = al
        sheet0["D9"].alignment = al
        sheet0["E9"].alignment = al
        sheet0["F9"].alignment = al
        sheet0["G9"].alignment = al
        sheet0.row_dimensions[1].height = 18
        sheet0.row_dimensions[2].height = 18
        sheet0.row_dimensions[3].height = 18
        sheet0.row_dimensions[5].height = 18
        sheet0.row_dimensions[6].height = 18
        sheet0.row_dimensions[8].height = 18
        sheet0.row_dimensions[9].height = 18
        _count = []
        for i in ["��������", "��̬����", "��ʼ����"]:
            _sheet = _excel.create_sheet(i)
            _sheet["A1"] = "ʱ��"
            _sheet["B1"] = "����"
            _sheet["C1"] = "ϡ�ж�"
            _sheet["D1"] = "��ɫ��"
            _sheet["E1"] = "�ܴ���"
            _sheet["F1"] = "����ˮλ"
            _sheet.column_dimensions['A'].width = 23
            _sheet.column_dimensions['B'].width = 20
            _sheet.column_dimensions['C'].width = 10
            _sheet.column_dimensions['D'].width = 15
            _sheet.column_dimensions['E'].width = 10
            _sheet.column_dimensions['F'].width = 10
            _sheet.row_dimensions[1].height = 20
            _sheet["A1"].font = fon1
            _sheet["B1"].font = fon1
            _sheet["C1"].font = fon1
            _sheet["D1"].font = fon1
            _sheet["E1"].font = fon1
            _sheet["F1"].font = fon1
            _sheet["A1"].alignment = al
            _sheet["B1"].alignment = al
            _sheet["C1"].alignment = al
            _sheet["D1"].alignment = al
            _sheet["E1"].alignment = al
            _sheet["F1"].alignment = al
            _list = _dir[i]
            n_a = 1
            n_sr = 0
            n_ssr = 0
            count = [0, 0, 0, 0, 0, 0, [], []]
            for [t, p, v, c] in _list:
                n_a += 1
                n_sr += 1
                n_ssr += 1
                print(t, p, v, c, n_a)
                _a = _sheet[f"A{n_a}"]
                _b = _sheet[f"B{n_a}"]
                _c = _sheet[f"C{n_a}"]
                _d = _sheet[f"D{n_a}"]
                _e = _sheet[f"E{n_a}"]
                _f = _sheet[f"F{n_a}"]
                _sheet[f"A{n_a}"] = t
                _sheet[f"B{n_a}"] = p
                _sheet[f"C{n_a}"] = v
                _sheet[f"D{n_a}"] = c
                _sheet[f"E{n_a}"] = n_a - 1
                _sheet[f"F{n_a}"] = n_ssr
                _sheet[f"A{n_a}"].alignment = al
                _sheet[f"B{n_a}"].alignment = al
                _sheet[f"C{n_a}"].alignment = al
                _sheet[f"D{n_a}"].alignment = al
                _sheet[f"E{n_a}"].alignment = al
                _sheet[f"F{n_a}"].alignment = al
                if v == "N":
                    _fon = fon_n
                    count[0] += 1
                elif v == "R":
                    _fon = fon_r
                    count[1] += 1
                elif v == "SR":
                    _fon = fon_sr
                    count[2] += 1
                    count[6] += [f"{c}({n_sr})"]
                    n_sr = 0
                elif v == "SSR":
                    _fon = fon_srr
                    count[3] += 1
                    count[7] += [f"{c}({n_ssr})"]
                    n_ssr = 0
                else:
                    print("ϡ�ж��쳣")
                    continue
                _sheet[f"A{n_a}"].font = _fon
                _sheet[f"B{n_a}"].font = _fon
                _sheet[f"C{n_a}"].font = _fon
                _sheet[f"D{n_a}"].font = _fon
                _sheet[f"E{n_a}"].font = fon2
                _sheet[f"F{n_a}"].font = fon2
                _sheet.row_dimensions[n_a].height = 18
            count[4] = n_a-1
            count[5] = n_ssr
            _count += [count]
        sheet0["B3"] = _count[0][0]
        sheet0["C3"] = _count[0][1]
        sheet0["D3"] = _count[0][2]
        sheet0["E3"] = _count[0][3]
        sheet0["F3"] = _count[0][4]
        sheet0["G3"] = _count[0][5]

        _list = _count[0][6]
        _str = ""
        for i in _list:
            _str += i + " "
        sheet0["I2"] = _str
        _list = _count[0][7]
        _str = ""
        for i in _list:
            _str += i + " "
        sheet0["I3"] = _str

        sheet0["B6"] = _count[1][0]
        sheet0["C6"] = _count[1][1]
        sheet0["D6"] = _count[1][2]
        sheet0["E6"] = _count[1][3]
        sheet0["F6"] = _count[1][4]
        sheet0["G6"] = _count[1][5]
        _list = _count[1][6]
        _str = ""
        for i in _list:
            _str += i + " "
        sheet0["I5"] = _str

        _list = _count[1][7]
        _str = ""
        for i in _list:
            _str += i + " "
        sheet0["I6"] = _str
        sheet0["B9"] = _count[2][0]
        sheet0["C9"] = _count[2][1]
        sheet0["D9"] = _count[2][2]
        sheet0["E9"] = _count[2][3]
        sheet0["F9"] = _count[2][4]
        sheet0["G9"] = _count[2][5]
        _list = _count[2][6]
        _str = ""
        for i in _list:
            _str += i + " "
        sheet0["I8"] = _str

        _list = _count[2][7]
        _str = ""
        for i in _list:
            _str += i + " "
        sheet0["I9"] = _str
        _excel.remove(_excel['Sheet'])
        import time
        now = time.strftime("%Y-%m-%d %H-%M-%S", time.localtime())
        _path = f"personal/snows/roll/�������������¼ - {now}.xlsx"
        _excel.save(_path)
        self.main.indicate("�����¼�ѵ���")
