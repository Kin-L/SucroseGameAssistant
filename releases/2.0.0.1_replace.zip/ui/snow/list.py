# -*- coding:gbk -*-
from ui.element.control import *


class SnowList:
    def __init__(self, widget, location):
        # �����б�����
        scroll = ScrollArea(widget, location)
        scroll.setFrameShape(QtWidgets.QFrame.Shape(0))
        # ���ÿؼ�
        self.label_snow = Label(scroll, (75, 10, 80, 20), "���׽���", 18)
        setpath = "assets/main_window/ui/set.png"
        self.set_snow = PicButton(scroll, (180, 10, 22, 22), setpath, (22, 22))

        self.check_share = Check(scroll, (15, 50, 140, 22), "��֪����")
        self.check_fight = Check(scroll, (15, 95, 140, 22), "�����ж�")
        self.check_debris = Check(scroll, (15, 140, 140, 22), "���˹���")
        self.check_market = Check(scroll, (15, 185, 140, 22), "ÿ�����")
        self.check_reward = Check(scroll, (15, 230, 140, 22), "�ճ�����")
        self.check_proof = Check(scroll, (15, 275, 140, 22), "��ȡƾ֤")
        self.check_mail = Check(scroll, (15, 320, 140, 22), "��ȡ�ʼ�")
        self.check_fragment = Check(scroll, (15, 365, 140, 22), "��ԴѲ��")
        self.check_roll = Check(scroll, (15, 410, 140, 22), "������¼")

        self.set_share = PicButton(scroll, (180, 50, 22, 22), setpath, (22, 22))
        self.set_fight = PicButton(scroll, (180, 95, 22, 22), setpath, (22, 22))
        self.set_debris = PicButton(scroll, (180, 140, 22, 22), setpath, (22, 22))
        self.set_market = PicButton(scroll, (180, 185, 22, 22), setpath, (22, 22))
        self.set_reward = PicButton(scroll, (180, 230, 22, 22), setpath, (22, 22))
        self.set_proof = PicButton(scroll, (180, 275, 22, 22), setpath, (22, 22))
        self.set_mail = PicButton(scroll, (180, 320, 22, 22), setpath, (22, 22))
        self.set_fragment = PicButton(scroll, (180, 365, 22, 22), setpath, (22, 22))
        self.set_roll = PicButton(scroll, (180, 410, 22, 22), setpath, (22, 22))
